#include<iostream>
#include"WindGauge.h"
#include<deque>

using namespace std;

    //   void WindGauge:: get_history(deque<int>&newhistory){
    //        history = newhistory;
    //    }

    WindGauge :: WindGauge(int period){
        //int count = period;
    }

    void WindGauge :: set_addval(deque<int>&new_addval){
        addval = new_addval;
    }
    
    deque<int> WindGauge ::get_addval(){
        return addval;
    }

    void WindGauge :: set_count(int& newcount){
        count = newcount;
    }

    int WindGauge :: get_count(){
        return count;
    }

    // deque<int> WindGauge :: set_addval(deque<int>& new_addval){
    //         addval = new_addvaal;
    // }

    // deque<int> WindGauge ::get_addval(){
    //}

    void WindGauge :: currentWindSpeed(int speed){
        addval.push_back(speed);
        int count = -1;
            for (auto iter = addval.begin(); iter != addval.end() ; iter++){
                count++;
            }    

            cout << count;
            if (count == 12)
            {
                addval.pop_front();
    }
    }

    int WindGauge :: highest() const{
        int high = 0;

        for (auto iter = addval.begin(); iter != addval.end(); iter++)
        {
            if (high < *iter) high = *iter;
        }
            return high;
    }

    int WindGauge :: lowest() const{
        auto iter = addval.begin();
        int low = *iter;

        for (auto iter = addval.begin(); iter != addval.end() ; iter++)
        {
            if (low > *iter) low = *iter;
        }
        return low;
    }


    int WindGauge :: average() const{

        int avr = 0;
        int i = 0;
            for (auto iter = addval.begin(); iter != addval.end() ; iter++){
            avr = avr + *iter;
            i++;
            }
            avr = avr / i;
            return avr;
    }


    void WindGauge :: dump(int high, int low, int avr){

        cout << endl;
        cout << "The highest: "<<  high << endl;
        cout << "The lowest: " << low << endl;
        cout << "The average: " << avr << endl;
        cout << endl;
         
    }

    void WindGauge :: print(){
        for (auto iter = addval.begin(); iter != addval.end(); iter++)
        {
            cout << *iter << endl;
        }
        
    }

    



