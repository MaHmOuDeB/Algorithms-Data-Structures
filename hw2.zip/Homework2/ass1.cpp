/*Write a program which does the following using twolistobjects:
1.  Create two lists (AandB).
2.  Read integers from the keyboard until the entered integer is negative or zero.
3.  Insert the positive integers into listA by adding to the end.
4.Insert the same positive integers into listB by adding to the beginning.

5.  Print listA(separated  by  spaces)  on  the  standard  output  and  print  listB(separated  byspaces) into a file called “listB.txt”.
6.  Print an empty line on the standard output.
7.  Move the first element of the lists to the end (for both lists).
8.  Print listA, print listB on the standard output (both separated by comma) using an iterator.Make sure that you do not print a comma after the last element.
9.  Print an empty line on the standard output.
10.  Merge listB into listA.
11.  Print the result of the merging as a sorted list on the standard output (separated by spaces).
*/

#include<iostream>
#include<list>
#include<iterator>
#include<fstream>


using namespace std;

// Function for printing list in the standard output
void print_list(list <int> list){

for (auto iter = list.begin(); iter != list.end(); iter++)
{
    cout << *iter << " ";
}
cout << endl;
}



int main(){

list <int> alist, blist; //Creation of two arrays
int count = 1;
int numbers;
cin >> numbers;
while (numbers >0) //Number has to be strictly positive
{
    //Inserting elements in the back(end)
    alist.push_back(numbers);
    //Insert element in the front(beginning)
    blist.push_front(numbers);
    cin >> numbers;
    count++;
    }

cout << endl;

print_list(alist); // Print listA in standard output


ofstream  ourfile; // Declaring an instance for opening up the file
ourfile.open("listB.txt"); // opening the file

//printing elements of listB in the file
for (auto iter = blist.begin(); iter != blist.end(); iter++)
{
    ourfile << *iter << " ";
}

cout << endl;   // empty line 

//move first element of the listA to the back
auto iter = alist.begin();
alist.push_back(*iter);
alist.pop_front();

//move first element of the listB to the back
auto iter1 = blist.begin();
blist.push_back(*iter1);
blist.pop_front();

//Printing both lists in the standard output with the use of iterators
int i = 1;
    for (auto iter = alist.begin(); iter != alist.end(); iter++){
    cout << *iter;
    i++;
        if(i < count){
            cout << ",";
        }
}
cout << endl;

     i = 1;
    for (auto iter = blist.begin() ; iter != blist.end() ; iter++){
    cout << *iter;
    i++;
        if(i < count){
            cout << ",";
        }
}
cout << endl;

cout << endl;

// Merging listB into listA

    for(auto miter = blist.begin() ; miter != blist.end() ; miter++){
    alist.push_back(*miter);
}

//Printing the merged list
print_list(alist);
ourfile.close();
return 0;

}


    




