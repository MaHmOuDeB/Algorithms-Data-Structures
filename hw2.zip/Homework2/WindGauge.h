#include<iostream>
#include<deque>

using namespace std;

class WindGauge {
    public:
    WindGauge(int period = 12);
    void currentWindSpeed(int speed);
    int highest() const;
    int lowest() const;
    int average() const;
    //void get_history(deque<int>&newhistory);
    void set_addval(deque<int>& new_addval);
    deque<int>get_addval();
    void set_count(int& newcount);
    int get_count();
    void dump(int high, int low, int avr); 
    void print();

    private:
    // add properties and/or method(s) here};
    deque <int> addval; // deque with 12 elements
    int count = 0;




};