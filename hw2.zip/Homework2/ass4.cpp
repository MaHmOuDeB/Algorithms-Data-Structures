/*Write a program which fills a vector with the integer values from1to30.
 Then add the value 5 at the end of the vector.
Reverse the vector using the reverse() function from the algorithm library
Print the content of the vector on the standard output using an iterator.
Then replace all occurrences of the value 5 by the value 129 using the
replace() function from the algorithm library 
print the modified vector again on the standard output.*/


#include<iostream>
#include<vector>
#include<algorithm>

using namespace std;

int main(){

vector <int> vec;
//Adding value to the vector from 1 to 30
//And adding 5 at the end of the vector
    for(int i = 1 ; i <= 30 ; i++ ){
        if (i == 30) vec.push_back(5);
        else vec.push_back(i);
        
    }
//Reversing the vector
reverse(vec.begin(), vec.end());

//Printing the vectors 
for (auto iter = vec.begin(); iter != vec.end(); iter++)
{
    cout << *iter << " ";
}
cout << endl << endl;


//replace 5 by 129 in the vector
replace(vec.begin(), vec.end(), 5, 129);

//Printing the newly modified vector
for (auto iter = vec.begin(); iter != vec.end(); iter++)
{
    cout << *iter << " ";
}
cout << endl;


return 0;
}












