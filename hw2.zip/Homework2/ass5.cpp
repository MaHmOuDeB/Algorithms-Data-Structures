/*In the lottery 6 out of 49 numbers are randomly drawn.
Draw six different numbers using theformula rand() % 49 + 1.
Then add the drawn number to a container that stores all drawn numbers (but make sure that your container will not contain duplicates).
After you have drawn all numbers, print them on the standard output in ascending order.\
Usea suitable STL container that supports the needed operations and corresponding iterators for all actions.
Make sure that you initialize the random number generator with the local time of yoursystem at the beginning of your program.*/

#include<iostream>
#include<set>
#include<time.h>

using namespace std;

int main(){
int i = 0;
int number;
set <int> lottery;


srand(time(NULL)); //Initialisation of random funcion

//pair<set<int>::iterator, bool> result; //Using pair to check if entered element is not a dublicate

while (i < 6)
{
number = rand() % 49 + 1;  //Generation of random number
auto result = lottery.insert(number);
    if (!result.second)  //Check for dublicates
    {
        cout << "Failed to insert " << number << endl;
        i--;
    }
i++;
}

//Print in ascending order
for (auto iter = lottery.begin(); iter != lottery.end(); iter++)
{
    cout << *iter << " ";
}
cout << endl << endl;
 
return 0;
}