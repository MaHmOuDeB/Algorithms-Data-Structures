#include<iostream>
#include"WindGauge.cpp"
#include<deque>

using namespace std;

int main(){

    WindGauge s1;
    deque<int> addval;
    // int speed;
    // int count = 0;
    // int high, low, avr;
    s1.currentWindSpeed(15);
    s1.currentWindSpeed(16);
    s1.currentWindSpeed(12);
    s1.currentWindSpeed(15);
    s1.currentWindSpeed(15);
    // s1.highest();
    // s1.lowest();
    // s1.average();
    s1.dump(s1.highest(), s1.lowest(), s1.average());

     s1.currentWindSpeed(16);
    s1.currentWindSpeed(17);
    s1.currentWindSpeed(16);
    s1.currentWindSpeed(16);
    s1.currentWindSpeed(20);
     s1.currentWindSpeed(17);
    s1.currentWindSpeed(16);
    s1.currentWindSpeed(15);
    s1.currentWindSpeed(16);
    s1.currentWindSpeed(20);

    s1.dump(s1.highest(), s1.lowest(), s1.average());

    s1.print();








}
