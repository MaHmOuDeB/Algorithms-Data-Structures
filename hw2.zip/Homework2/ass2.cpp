/*
Write a program which does the following using adequeobject:
1.  Create a deque A able to store float values.
2.  Read floats from the keyboard until the entered float value is 0.
3.  Insert the positive elements at the end of A and the negative elements at the beginning ofA.
4.  Print the elements of A on the standard output separated by spaces.
5.  Print an empty line on the standard output.
6.  Add the value 0 into the middle of the deque (between the last negative and before the first positive element).
7.  Print the elements of A on the standard output separated by semicolons.
    Make sure that you do not print a semicolon after the last element.You can assume that the input will be valid.
    */

#include<iostream>
#include<deque>

using namespace std;


void p_deque(deque <float> deque){
    for (auto iter = deque.begin(); iter != deque.end() ; iter++)
    {
        cout << *iter << " " ;
    }
cout << endl;

}


int main(){

deque <float> A;

float floats;
int count = 1;

cin >> floats;
    while(floats != 0){
    if(floats > 0) A.push_back(floats); // positive elements inserted in the end
    else A.push_front(floats);         //Negative elements inserted in the beginning
    cin >> floats;
    count++;
    }

    cout << endl;

//Print the deque
p_deque(A);

cout << endl;

// Adding the 0 in the middle of the deque

auto iter = A.begin();

while (*iter < 0 ) iter++; //Iterate until the first non negative
iter = A.insert(iter , 0); // Inserting 0 before the first non negative element

//Printing the elements of the deque with comma in between

int i = 1;
for (auto iter = A.begin(); iter != A.end() ; iter++)
    {
        i++;
        cout << *iter;
            if (i < count)
            {
                cout << ",";
            }
    }
cout << endl;

return 0;

}