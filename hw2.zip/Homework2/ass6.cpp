#include<iostream>
#include<map>
#include<fstream>

using namespace std;

int main(){
    string info;
    string birthday;
    map<string , string > person;
    //open the file
    ifstream inFile;
    inFile.open("mapfile.txt");

        if (inFile.fail())
        {
            cout << "File not opened" << endl; //see if file was opened succesfully
            exit(1);
        }

    //Read File until reaching the end of file
        while (!inFile.eof() )
        {
            getline(inFile, info);      //Getting names
            getline(inFile, birthday ); //Gettting birthdays
           person.insert(pair<string, string>(info, birthday)); //inserting data in a map

        }
    inFile.close(); //Closing the file
        
        cout << "Search for name: ";
        getline(cin,info);  //Get name from user
        auto iter = person.find(info);
            if (iter == person.end())
            {
                cout << "Name not found" << endl;
            }
            else cout << (*iter).second << endl;    //Show the birthday of the entered name
            


        
}