#include<iostream>

// C++ program for implementation of selection sort  
using namespace std;

//Swap the smallest unsorted element with the current one
void swapping_f(int *xp, int *yp)  
{  
    int temp = *xp;  
    *xp = *yp;  
    *yp = temp;  
}  
  
void selectionSort(int arr[], int n)  
{  
    int current, unsorted, smallest;  
  
    // loop through the unsorted part of the array 
    for (current = 0; current < n-1; current++)  
    {  
        // This part of the code let us find the smallest element in the array
        // after the sorted elements  
        smallest = current;  
        for (unsorted = current+1; unsorted < n; unsorted++)  
        if (arr[unsorted] < arr[smallest])  
            smallest = unsorted;  //comparing the first unsorted element with 
                           //the right part of the array (unsorted part)
  
        // Swap the found minimum element with the first element  
        swapping_f(&arr[smallest], &arr[current]); // swap the smallest unsorted element of the  
                                             //with the current element 
    }  
}  
  
/* Function to print an array */
void printArray(int arr[], int size)  
{  
    int i;  
    for (i=0; i < size; i++)  
        cout << arr[i] << " ";  
    cout << endl;  
}  
  
// Driver program to test above functions  
int main()  
{  
    int arr[] = {64, 25, 12, 22, 11};  
    int n = sizeof(arr)/sizeof(arr[0]);  
    selectionSort(arr, n);  
    cout << "Sorted array: \n";  
    printArray(arr, n);  
    return 0;  
}  
  
// This is code is contributed by rathbhupendra 


// https://www.geeksforgeeks.org/selection-sort/



/*1- 2) We have the Sudo code:
2- for i=1 to n-1 min = i
3-  for j = i+1 to n
4-   if A[j] < A[min]
5-      min = j
6-  swap A[i] with A[min]

We are interested in the inner loop from line 3 to 5

    Loop invariant:
    At the start of each iteration of the i loop we, we can see that
    the element A[min] is less than or equal to the element A[i...j -1]
    And we know that j = i + 1
    so the array A[i ... j-1] is basically just the element A[i]

    Initialisation:
    Before the first iteration of tge loop  we have min = i 
    we can see that min idexed is the smallest element and only element
    in subarray A[i ... j-1], so the loop invariant is true

    Maintannce:
During the iteration, we  can see that we have two cases:
- A[j] > A[min] in this case the if statement in not true.
Thus nothing is executed. 

 or A[j] < A[min] in this case we can see that line 5 switches 
 min to index location j since it is the smallest.
 If min indexes an element less than or equal to elements in subarray 
 A[i...j-1].
 Line 5 switches min to index and hence after the loop iteration finishes
 min indexes the smallest element in subarray A[i...j]

    Termination:
At termination of the inner loop min min indexes
 an element less than or equal to all elements in subarray A[i..n]
  since j = n+1 upon termination.
   This finds the smallest element in this subarray
and is useful to us in the outer loop 
because we can move that next smallest item into the correct location.


*/