#include <stdio.h>
#include <iostream>
#include <cmath>
#include <array>
#include <chrono>
#include <map>
#include <iomanip>
#include <fstream>

using namespace std;
using namespace std::chrono;

template <typename T>
void printElement(T t, const int &width)
{
    cout << left << setw(width) << setfill(' ') << setfill(' ') << t;
}

//Naive recursice
unsigned int nFibonacci(int n)
{
    // Timer timer;

    if (n < 2)
        return n;

    else
        return nFibonacci(n - 1) + nFibonacci(n - 2);
}

//Bottom up
unsigned int bFiboniacci(int n)
{

    int Fib[n + 1]; //To store n-th term we need an array of size n+1
    Fib[0] = 0;
    Fib[1] = 1;

    for (int i = 2; i <= n; i++)
    {
        Fib[i] = Fib[i - 1] + Fib[i - 2];
    }
    return Fib[n];
}

//Power number (Divide and Conquer)
double power(double x, unsigned int n)
{
    double temp = 1;
    //double tempOdd = 1;
    if (n == 0)
        return 1;

    temp = power(x, n / 2);
    //tempOdd = power(x, (n - 1) / 2);

    if (n % 2 == 0)
        return (temp * temp); //If the power is even return the multiplication
                              // Of the two subdivsions

    else
        return (x * temp * temp); //If the power is odd return the multiplication of
                                  //the two sbdivsions and the number to have x^n
}

//Closed form
unsigned int cFibonacci(int n)
{
    double number = ((1 + sqrt(5)) / 2);
    double Fibn = power(number, n);
    return Fibn / sqrt(5);
}

void multiplication(unsigned int F[2][2], unsigned int M[2][2])
{
    int a = F[0][0] * M[0][0] + F[0][1] * M[1][0];
    int b = F[0][0] * M[0][1] + F[0][1] * M[1][1];
    int c = F[1][0] * M[0][0] + F[1][1] * M[1][0];
    int d = F[1][0] * M[0][1] + F[1][1] * M[1][1];
    F[0][0] = a;
    F[0][1] = b;
    F[1][0] = c;
    F[1][1] = d;
}

//Power of a number for matrices
void mpower(unsigned int F[2][2], int n)
{
    unsigned int mF[2][2] = {{1, 1}, {1, 0}};

    if (n == 0 || n == 1)
        return;

    mpower(F, n / 2);
    multiplication(F, F);

    if (n % 2 != 0)
        multiplication(F, mF);
}

//MATRIX Representation
unsigned int mFibonacci(unsigned int n)
{

    unsigned int Fib[2][2] = {{1, 1}, {1, 0}};
    if (n == 0)
        return 0;
    mpower(Fib, n - 1);
    return Fib[0][0];
}

int main()
{
    map<int, float> timemap;
    ofstream funcFile;
    funcFile.open("funcfile.dat", ios::out | ios::trunc);

    unsigned int n = 1;
    std::chrono::time_point<std::chrono::steady_clock> starttime, endtime;
    std::chrono::duration<float> duration;

    cout << "Naive Representation:" << endl;

    starttime = std::chrono::high_resolution_clock::now();
    while (n < 50)
    {

        cout << n << "  :   " << nFibonacci(n) << endl;

        endtime = chrono::high_resolution_clock::now();
        duration = endtime - starttime;
        float ms = duration.count() * 1000.0f;
        //std::cout << "Time to run Function: " << ms << " ms" << endl;
        timemap[n] = ms;

        if (ms > 300.00)
            break;

        if (n < 5)
            n++;
        else if (n < 10 && n >= 5)
            n = n + 2;
        else if (n < 20 && n >= 10)
            n = n + 4;
        else if (n < 40 && n >= 20)
            n = n + 8;
        else if (n < 60 && n >= 40)
            n = n + 10;
    }

    //Bottom up
    map<int, float> btimemap;
    n = 1;
    cout << endl
         << endl;
    cout << "Bottom Up REPRESENTATION " << endl;
    starttime = std::chrono::high_resolution_clock::now();
    while (n < 50)
    {

        cout << n << "  :   " << bFiboniacci(n) << endl;

        endtime = chrono::high_resolution_clock::now();
        duration = endtime - starttime;
        float ms = duration.count() * 1000.0f;
        // std::cout << "Time to run Function: " << ms << " ms" << endl;
        btimemap[n] = ms;
        if (ms > 1000.00)
            break;

        if (n < 5)
            n++;
        else if (n < 10 && n >= 5)
            n = n + 2;
        else if (n < 20 && n >= 10)
            n = n + 4;
        else if (n < 40 && n >= 20)
            n = n + 8;
        else if (n < 60 && n >= 40)
            n = n + 10;
    }

    //Closed Form
    map<int, float> Ctimemap;
    n = 1;
    cout << "Closed Form REPRESENTATION " << endl;
    starttime = std::chrono::high_resolution_clock::now();
    while (n < 60)
    {

        cout << n << "  :   " << cFibonacci(n) << endl;

        endtime = chrono::high_resolution_clock::now();
        duration = endtime - starttime;
        float ms = duration.count() * 1000.0f;
        // std::cout << "Time to run Function: " << ms << " ms" << endl;
        Ctimemap[n] = ms;
        if (ms > 1000.00)
            break;

        if (n < 5)
            n++;
        else if (n < 10 && n >= 5)
            n = n + 2;
        else if (n < 20 && n >= 10)
            n = n + 4;
        else if (n < 40 && n >= 20)
            n = n + 8;
        else if (n < 60 && n >= 40)
            n = n + 10;
    }

    //Matrix Representation
    map<int, float> Mtimemap;
    n = 1;
    cout << "MATRIX REPRESENTATION " << endl;
    starttime = std::chrono::high_resolution_clock::now();
    while (n < 60)
    {

        cout << n << "  :   " << mFibonacci(n) << endl;

        endtime = chrono::high_resolution_clock::now();
        duration = endtime - starttime;
        float ms = duration.count() * 1000.0f;
        // std::cout << "Time to run Function: " << ms << " ms" << endl;
        Mtimemap[n] = ms;
        if (ms > 1000.00)
            break;

        if (n < 5)
            n++;
        else if (n < 10 && n >= 5)
            n = n + 2;
        else if (n < 20 && n >= 10)
            n = n + 4;
        else if (n < 40 && n >= 20)
            n = n + 8;
        else if (n < 60 && n >= 40)
            n = n + 10;
    }

    // separator = ' ';
    // numWidth = 20;
    // timeWidth = 20;
    // cout << endl
    //      << endl;
    // funcFile << "n"
    //          << "                                               "
    //          << "Matrix multiplication" << endl;
    // for (auto it = Mtimemap.begin(); it != Mtimemap.cend(); it++)
    // {

    //     funcFile << (*it).first << "                                             " << (*it).second << endl;

    //     cout << endl;
    // }

    funcFile << "n"
             << "        "
             << "Naive  recursive"
             << "        "
             << "Bottom up"
             << "      "
             << "Closed form"
             << "         "
             << "Matrix multiplication" << endl;

    for (int i = 0; i < 60; i++)
    {
        if (timemap[i] != 0)
        {
            funcFile << i << "          " << timemap[i] << "                 " << btimemap[i] << "        " << Ctimemap[i] << "            " << Mtimemap[i] << endl;
        }
    }

    return 0;
}

// struct Timer
// {
//     std::chrono::time_point<std::chrono::steady_clock> starttime, endtime;
//     std::chrono::duration<float> duration;
//     map<int, float> timemap;
//     float ms = duration.count() * 1000.0f;

//     Timer()
//     {
//         starttime = std::chrono::high_resolution_clock::now();
//     }

//     ~Timer()
//     {
//         endtime = chrono::high_resolution_clock::now();
//         duration = endtime - starttime;

//         ms = duration.count() * 1000.0f;
//     }
// };