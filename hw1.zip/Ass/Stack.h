#include<iostream>


using namespace std;

template <class T, int initialsize = 10>
class Stack{
    T* ptr;  //where data will be stored
    int position; // Position of the last element in the Stack
    int size; //Size of the array
    void extend(); //function to extend the size of the array when full

        public:
    Stack();  //build the stack with 10 positions
    ~Stack(); //Destructor
    Stack(const Stack&); // Create a copy of the Stack
    Stack(int Size); // set the Stack size
    bool Push(const T element); //Add an element in the top and return a bool depeding on cases
    bool Pop(T& out);  //Take off an element from the top and puts it in out variable
    T back(void); //returns data on top of the stack
    int getNumEntries(); // # of entries
};


