#include<cstdlib>
#include<iostream>

using namespace std;

// Complex class

class Complex {
	private:
		double re, im;
	public:
		Complex(double re, double im) {
			this->re = re;
			this->im = im;
		}
		Complex& operator=(const Complex o) {
			this->re = o.re;
			this->im = o.im;
			return *this;
		}
		
        //Complex operator ==(const Complex o)
        Complex operator +(Complex c2){
            return Complex(this->re + c2.re, this->im + c2.im);
        }

    //  return type   operator   name of the instance
        bool operator ==(Complex c2){
            if(this -> re == c2.re && this -> im == c2.im ) return 1;
            else return 0;
        }
		
};



// template of a function of an array of type T

template <typename T>
int array_search(T array[], int size, T element){
    
    

        for (int i = 0; i < size; i++)
        {
            if (array[i] == element)
                return i;
        }
        return -1;
}

// Test the functionalities of the function

int main(){


    int intarray[] = {1 , 2 , 3 , 4 , 5};
    cout << "Position of int: " << array_search(intarray, 5 , 4) << endl;;

    string sarray[] = {"Mahmoud", "Valentina", "Bobobo"};
    cout << "Position of string: " <<  array_search(sarray, 3, std::string("Valentina") ) << endl;

    Complex carray[] = {Complex(1,2) , Complex(3,4) , Complex(1,0)};
    cout << "Position of complex: " << array_search(carray, 3, Complex(1,0)) << endl;


    //What if I want to make a template for the element
    // That we are searching for

}
