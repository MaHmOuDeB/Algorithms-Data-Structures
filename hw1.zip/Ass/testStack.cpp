#include<iostream>
#include"Stack.h"

using namespace std;

template<class T, int initialsize >
Stack<T, initialsize>::Stack(){

    ptr = new T[initialsize]; //create a new vector
    size = initialsize;
    position = -1;     // position when no element is in the stack
} 

template<class T, int initialsize>
Stack<T, initialsize>::Stack(const Stack&copy){
                                //Copy the instances of the old stack in the copied stack
    size = copy.size;               
    position = copy.position;
    ptr = new T[size];          //Create a vector with the same size as the old vector

    for(int i = 0; i < size; i++ ){     //Copy data of the old stack on the new one
        ptr[i] = copy.ptr[i];
    }
}

template<class T, int initialsize>
Stack<T, initialsize>::Stack(int size){

    ptr = new T[size];                  //create a stack of a given size
    position  = -1;                     //No element in the Stack right now
}

template<class T, int initialsize>
bool Stack<T, initialsize>::Push(T element){
    
    if(position + 1 == size) return false; // reached the full size of the vector

    else{
        position++;                         //Add an element in the next position(new top)
        ptr[position] = element;
                             return true;
    }
}

template<class T, int initialsize>
bool Stack<T, initialsize>::Pop(T &out){
    if(position < 0) return false;
    else{
        out = ptr[position];               //Assign to out the popped element
        position--;                         //Adjust the number of elements in the stack
        return true;
    }
}

template<class T, int initialsize>
T Stack<T, initialsize>::back(void){
    return ptr[position++];                          //Data on top of the Stack
}

template<class T,int initialsize>
int Stack<T,initialsize>::getNumEntries(){
    return position+1;                             //Number of elements in the stack?
}

template<class T, int initialsize>
Stack<T, initialsize>::~Stack(){
    delete[] ptr;                                //deallocate memory
}

int main(){

int out;
    Stack <int> intstack;
    Stack <int> copystack;

    for (int i = 0; i < 10; i++)
    cout <<  intstack.Push(i) <<endl;

    cout << intstack.Pop(out) << endl;

    cout << intstack.back() << endl;

    cout << intstack.getNumEntries() << endl;
}

 //If we pop an element there will be a place for it even if where(position) moves or not?