#include<iostream>
#include<vector>

using namespace std;

int main(int argc, char** argv){

    string words[100];
    string word;
    int i = 0;
    int count = 0;

    cin >> word;
    while (word != "END"){  //loop and assign value of word to words until the word END is entered
        words[i] = word;
        cin >> word;
        i++;
    }

    cout << endl;
    // cout << "Printed numbers: " << endl;

    // for(int j = 0 ; j < i ; j++){
    //     cout << words[j] << endl;
    // }

    vector<string> vstring(0);

    for(int j = 0 ; j < i ; j++){
        vstring.push_back(words[j]);  //Include data in the vector
    }

        cout << "Print element of the vector using oeprator []: " << endl;

    for(int j = 0 ; j < vstring.size() ; j++){
        cout << vstring[j] << " ";     //Print data included in the vector
                                        //Using the overloaded index operator 
            
    }
        cout << endl;

        cout << "Print element of the vector using iterators: ";


    for(vector<string>::iterator iter = vstring.begin(); iter != vstring.end(); iter++){
        //Declating iterator and making point to the first element of the vector
        //iterator doesn't have to point to the element after the end!
        
        cout << *iter;
        count++;
            if(count < i){
                cout << ",";  //To not print the comma after the last element
            }
    }

    cout << endl;
    return 0;
}