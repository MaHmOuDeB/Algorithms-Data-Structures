#include<iostream>
#include"LinkedList.h"

using namespace std;

//Default constructor for class list
template <class T>
list<T>::list(){
    this -> front = NULL;
    this -> last = NULL;

}

//Default Constructor for struct Node
template <class T>
Node<T>::Node(){
    data = 0;
    this -> next = NULL;
    this -> prev = NULL;
    
}

template <class T>
list<T>::~list(){

struct Node<T>* node = front;
struct Node<T>* deleted = front;

    while (node -> next != NULL )
    {
        node = node -> next;
        delete[] deleted;
        deleted = node;
    }
}


template<class T>
list<T> :: list(const list& o)
{
	Node<T> *newNode = new Node<T>; //pointer to create a node
		Node<T> *current; //pointer to traverse the list

		if (o.first == NULL){     //otherList is empty
			front = NULL;
			last = NULL;
		}
        else
		{
			current = o.first; //current points to the list to be copied
			front->info = current->info; //copy the info
			front->next = current->next; //set the link field of the node to NULL
	        front->back = current->back;

	                last = front; //make last point to the first node

			current = current->next; //make current point to the next node
	                //copy the remaining list

	                while (current != NULL)
	                {
	        	   newNode = new Node<T>; //create a node
	        	   newNode->info = current->info; //copy the info
	        	   newNode->next = current->next;
			        newNode->back = current->back;
	        	   last->next = newNode;
	        	   last = newNode;
	        	   current = current->next;
	                 }
		}
}


template <class T>
Node<T>::Node(const Node& cpy){
  //  struct Node<T> node;
    data = cpy.data;
    prev = cpy.prev;
    next =cpy.next;
}



template <class T>
  void list<T>:: addfront(T value){

    // Creating new node
    struct Node<T>* newnode; // creating a new node
    newnode = new Node<T>();
    newnode -> data = value; //assining value to the new node
    newnode -> prev = NULL;  //first element of the list -> prev = NULL
    newnode -> next = front; // Link the node to the list

        if (front == NULL)
        {
            last = newnode;
        }
        else front -> prev = newnode;
        front = newnode;
}



template <class T>
void list<T>::addback(T value){

//Creating a new node
struct Node<T>* newnode ;
newnode = new Node<T>();
newnode -> data = value;
newnode -> prev = last;
newnode -> next = NULL;

    if (last == NULL)
    {
        front = newnode;
    }
    else last -> next = newnode;
    last = newnode;   
}

template <class T>
T list<T>::getfront(){
    if(front -> prev == NULL)
        return front->data; //return data of the front
    else
        return 0;
}

template<class T>
T list<T>::getback(){
    if(last -> next == NULL)
        return last -> data;
    else 
        return 0;
}

template <class T>
T list<T> :: removef(){
    Node<T>* remove = front;//set remove to the front
    front = remove -> next;//Move the pointer to the next node
    front -> prev = NULL;//Isolate the the old front

    T data;
    data = remove -> data;
    delete[] remove;
    return data;
}

template <class T>
T list<T> :: removel(){
//Same algorithm as the latter function but in the end of the list
    Node<T>* remove = last;
    last = remove -> prev;
    last -> next = NULL;
    
    T data;
    data = remove -> data;
    delete[] remove;
    return data;
}



template <class T>
int list<T> :: count(){
    int count = 1;
    Node<T>*cursor = front;

        if(cursor -> next ==NULL)
        return 0;

        else{
    while (cursor -> next != NULL)
    {
        count++;
        cursor = cursor -> next;
    }
return count;

        }
}


int main(){

list<int> l;
l.addfront(1);
l.addback(2);
l.addfront(10);
l.addback(20);
cout << l.getfront() << endl;
cout << l.getback() << endl;
cout << l.removef() << endl;
cout << l.removel() << endl;
cout << l.count() << endl;

return 0;
}