#include<iostream>

using namespace std;

template<class T>
struct Node{

    T data;
    struct Node* prev; // reference to the previous node
    struct Node* next; // reference to next node
    Node();
    Node(const Node&);
};


template <class T>
class list{
    Node<T>* front; //reference to the firt node
    Node<T>* last;   //reference to the last node
    public:
    list();  //Constructor
    ~list(); //Destructor
   // list(const list&);
    list(const list& );

    void addfront( T value); //Insert element in beginning
    void addback( T value); //insert element in the end
    T getfront(); //Returns the element in the front
    T getback();  //Returns element in the back (beginning)
    T removef(); // returns last element in the list and remove it
    T removel(); // returns first element in the list and remove it
    int count(); // Number of elements in the list

};



