#include<iostream>
#include<vector>

using namespace std;

int main(int argc, char** argv){
    string words[100];
    string word;
    int i = 0;
    //int count = 0;

    getline(cin, word);
    while (word != "END"){  //loop and assign value of word to words until the word END is entered
        words[i] = word;
        getline(cin, word);
        //cin >> word;
        i++;
    }

    cout << endl;

    vector<string> vstring(0);

    for(int j = 0; j < i; j++){
        vstring.push_back(words[j]);
    }

    cout << "Printed numbers in vector: " << endl;

    for(int j = 0 ; j < vstring.size() ; j++){
        cout << vstring[j] << endl;
    }
    
    if (i >= 5)swap(vstring[1], vstring[4]);  //SWAP THE SECOND AND THE FIFTH ELEMENT
    else cout << "One or both elements doesn't exist" << endl;


    // cout << "Printed numbers with changes in the vector: " << endl;

    // for(int j = 0 ; j < i ; j++){
    //     cout << vstring[j] << endl;
    // }
    vstring[i-1] = "???"; 

     cout << "Print element of the vector using oeprator []: " << endl;
        int count = 0;
        
    for(int j = 0 ; j < vstring.size() ; j++){
        cout << vstring[j];     //Print data included in the vector
                                //Using the overloaded index operator 
     count++;
            if(count < i){
                cout << ",";  //To not print the comma after the last element
            }
            
    }
        cout << endl;
        cout << endl;

        cout << "Print element of the vector using iterators: " << endl;
        count = 0;

    //Declaration of iterator
    vector<string>::iterator viter;


    for(viter = vstring.begin() ; viter != vstring.end(); viter++){
        cout <<*viter;
        count++;
            if(count < i){
                cout << ";";  //To not print the comma after the last element
            }
    }
    cout << endl;

    cout << "Iterate over elements in backward order" << endl;

    //Declaring our reverse iterator

    vector<string>::reverse_iterator rviter = vstring.rbegin();

        while(rviter != vstring.rend()){
            cout << *rviter << " ";
            rviter++;
        }


cout << endl << endl;

return 0;
}