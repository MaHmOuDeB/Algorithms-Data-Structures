#include<iostream>
#include<ctime>
#include<chrono>
#include<ctime>
#include<ratio>
#include<fstream>

using namespace std;
using namespace std::chrono;

void merge(int *A, int first , int last, int mid){

    int Llenght = mid - first + 1 ;
    int Rlenght = last  - mid;

 //size of left and right sub-arrays
    int L[Llenght];
    int R[Rlenght];

 //fill left and right sub-arrays
    for (int i = 0; i < Llenght; i++)
        L[i] = A[first + i];

    for (int i = 0; i < Rlenght; i++)
        R[i] = A[mid + i + 1];

    int l = 0, r = 0, a = first;

    while (r < Rlenght && l < Llenght)
        {
            if(L[l] <= R[r]) { //If the edge element in L is smaller or equal than the one in R
                A[a] = L[l];   //Past this element in the array
                l++;}

            else {      //If the edge element in R is smaller than the one in L
                        //Past this element in the array
            A[a] = R[r];
            r++;
            }
            a++;
        }

//extra element in left array
    while (r < Rlenght)
        {
            A[a] = R[r];
            r++;
            a++;
        }

   //extra element in right array     
    while (l < Llenght)
        {
            A[a] = L[l];
            l++;
            a++;
        }
}



void Insertion_sort(int *A, int first , int last){

    for (int i = first + 1 ; i <= last ; i++) //Loop to iterate through unsorted array
    {
        int value = A[i];
        int hole = i;
            while (hole > first && A[hole-1] > value ) //we shift the hole until the condition is false
            {
                A[hole] = A[hole-1]; //we shift the bigger value to the right
                hole = hole - 1;     //we shift the position of the hole
            }
            A[hole] = value;         //we place the value in the right position in the sorte part of the array
    }    

}


void merge_sort(int *A, int first , int last, int k){

    if (last - first + 1 < k)
    {
        Insertion_sort(A , first, last);
    }
    

    if(first < last){

int mid = first + ( last - first) / 2;
merge_sort(A , first , mid, k);
merge_sort(A , mid + 1 , last , k);
merge(A, first ,last , mid);

}

}

void reverseOrderOfArray(int arr[], int length) {
    int posMax, tmp;

    //go through all elements
    for (int i = 0; i < length - 1; i++) {
        //make current element min and remember its position
        posMax = i;
        //find tshe min in unsorted part
        for (int j = i + 1; j < length; j++) {
            if (arr[j] > arr[posMax]) {
                posMax = j;
            }
        }

        //swap min with current element if min is not current element
        if (posMax != i) {
            tmp = arr[i];
            arr[i] = arr[posMax];        
            arr[posMax] = tmp;
        }
    } 
}

void copyArray(int arr1[], int arr2[], int length) {
    for (int i = 0; i < length; i++) {
        arr2[i] = arr1[i];
    }
}

int main(){

 ofstream file;
    file.open("output1.dat");
    srand(time(NULL));

   int sz;
   cout<<"Enter the size of array::";
   cin>>sz;
   int array[sz];
   int reverseArr[sz];
   int bestCase[sz];
   int average_case[sz];

   for(int i=0;i<sz;i++)
      array[i]=rand()%1000;  //Generate number between 0 to 99
  
   cout<<"\nElements of the array::"<<endl;
  
  int k;
  cout << "How many subsequences we want:";
  cin >> k;
   
cout << "Our array" << endl;
    for (int i = 0; i < sz; i++)
    {
        cout << array[i] << " ";
    }
    cout << endl;

copyArray(array, bestCase, sz);
copyArray(array, reverseArr, sz);
copyArray(array, average_case, sz);

    

    cout << endl << endl;

merge_sort(array, 0 , sz , k);////////
    cout << "Sorted array: " << endl; //Best case
    merge_sort(bestCase, 0 , sz , k);
    for (int i = 0; i < sz; i++)
    {
        cout << array[i] << " ";
    }
    cout << endl;


    cout << "Reverse order:" << endl;
    reverseOrderOfArray(reverseArr, sz);
    for (int i = 0; i < sz; i++)
    {
        cout << reverseArr[i] << " ";
    }
    cout << endl;


    cout << "Average Case: " << endl;
    for (int i = 0; i < sz; i++)
    {
        cout << average_case[i] << " ";
    }
    cout << endl;









 
//Varying K
for(k = 1 ; k < sz ; k++){

    for(int i=0;i<sz;i++)
      array[i]=rand()%1000;  //Generate number between 0 to 9
  
  
   
cout << "Our array" << endl;
    for (int i = 0; i < sz; i++)
    {
        cout << array[i] << " ";
    }

copyArray(array, bestCase, sz);
copyArray(array, reverseArr, sz);
copyArray(array, average_case, sz);
cout << endl;

    cout << "Sorted array: " << endl; //Best case
    merge_sort(array, 0 , sz , k);
    for (int i = 0; i < sz; i++)
    {
        cout << array[i] << " ";
    }
    cout << endl;

//Best case
high_resolution_clock::time_point t1 = high_resolution_clock::now();
        merge_sort(array, 0, sz - 1, k);
 high_resolution_clock::time_point t2 = high_resolution_clock::now();
        // finish 
        //convert to microseconds
       double duration = duration_cast<microseconds>( t2 - t1 ).count();
        //write data to the file output.dat
        file << k << " " << duration << " " << endl;


//Worst case
        cout << "Reverse order:" << endl;
    reverseOrderOfArray(reverseArr, sz);
    for (int i = 0; i < sz; i++)
    {
        cout << reverseArr[i] << " ";
    }
    cout << endl;

//start measuring time
         t1 = high_resolution_clock::now();
        merge_sort(reverseArr, 0, sz - 1, k);
        t2 = high_resolution_clock::now();
        // finish 
        //convert to microseconds
         duration = duration_cast<microseconds>( t2 - t1 ).count();
        //write data to the file output.dat
        file << k << " " << duration << " ";



//Average case

cout << "Average Case: " << endl;
    for (int i = 0; i < sz; i++)
    {
        cout << average_case[i] << " ";
    }
    cout << endl;

 t1 = high_resolution_clock::now();
        merge_sort(average_case, 0, sz - 1, k);
        t2 = high_resolution_clock::now();
        // finish 
        //convert to microseconds
         duration = duration_cast<microseconds>( t2 - t1 ).count();
        //write data to the file output.dat
        file << k << " " << duration << " ";

        cout << endl << endl;

}


return 0;
}



/* CODE FOR PLOTING

set terminal pdf
set output "plot1.pdf"

# x and y labels
set xlabel "Value of the k"
set ylabel "Computation time, ms"
set title "Problem 2.1 (c)"

# Line styles
set style line 1 \
    linecolor rgb "#0060ad" \
    linetype 1 linewidth 2 \
    pointtype 7 pointsize 1.5

set style line 2 \
    linecolor rgb "#ff0000" \
    linetype 2 linewidth 2 \
    pointtype 7 pointsize 1.5

set style line 3 \
    linecolor rgb "#008000" \
    linetype 3 linewidth 2 \
    pointtype 7 pointsize 1.5

set grid

plot "output1.dat" using 1:2 title "Worst Case"  with lines linestyle 1,\
     "output1.dat" using 3:4 title "Average Case" with lines linestyle 2,\
     "output1.dat" using 5:6 title "Best Case" with lines linestyle 3


set output "plot2.pdf"

set xlabel "Value of the n"
set ylabel "Computation time, ms"
set title "Problem 2.1 (b) k = 20"

plot "output2.dat" using 1:2 title "Worst Case"  with lines linestyle 1,\
     "output2.dat" using 3:4 title "Average Case" with lines linestyle 2,\
     "output2.dat" using 5:6 title "Best Case" with lines linestyle 3

set output "plot3.pdf"

set xlabel "Value of the n"
set ylabel "Computation time, ms"
set title "Problem 2.1 (b) k = 50"

plot "output3.dat" using 1:2 title "Worst Case"  with lines linestyle 1,\
     "output3.dat" using 3:4 title "Average Case" with lines linestyle 2,\
     "output3.dat" using 5:6 title "Best Case" with lines linestyle 3

     */




/* QUESTION c)
For the best case we can see that the algorithm takes less time to execute for bigger Ks 
This is becauuse the array is alreay sorted so the program doesn't need time to execute the merge sort algorithm and moving element through the array 
We can see that for bigger K's we have the programs execute faster fpr the sorted array because the insertion sort is better in smaller numbers than merge sort 
