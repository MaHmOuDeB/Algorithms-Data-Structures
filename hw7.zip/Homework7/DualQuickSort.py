import random


#DUAL PIVOT QUICKSORT: Partition elements in elements smaller than the first pivot,
# Elements that are between the first and second pivot
#Elements that are bigger than the first second pivot
#The right pivot has to be smaller than the left one in this algorithm
def DualQuickSort(A , left ,right):
    if left >= right:
        return

    #A[1] , A[right] = A[right] , A[1]       #USING the second element as a pivot
    p = left
    q = right
    l = left + 1
    k = l
    g = right - 1
    if A[p] > A[q]:
        A[left] , A[right] = A[right] , A[left]
    while k <= g:
        if A[k] < A[p]:     #if the element in k is smaller than the element of the left pivot
            A[k] , A[l] = A[l] , A[k] #Elements smaller than left pivot in the left
            l = l + 1
        else:
            if A[k] > A[q]:        #if element in k is bigger than the element in the right pivot
                while A[g] > A[q] and k < g:       #while the element in g is bigger than the right pivot
                    g = g - 1
                A[k] , A[g] = A[g] , A[k]       #Make elements bigger than right pivot in the right
                g = g - 1                       #end place the element in between

                if A[k] < A[p]:
                    A[k] , A[l] = A[l] , A[k]
                    l = l + 1
        k = k + 1

    l = l - 1
    g =  g + 1
    A[l] , A[left] = A[left] , A[l]     #place the left pivot in the right place
    A[g] , A[right] = A[right] ,A[g]        #Place the right pivot in the right place
    DualQuickSort(A, left, l - 1)
    DualQuickSort(A, l + 1, g - 1)
    DualQuickSort(A, g + 1, right)


#MODIFIED RANDOM QUICK SORT: This algorithm randomize the chosen pivots in order to escape the worst case time complexity
#This algorithm uses the two pivots in order to make it marginally more efficient than the random quick sort in terms of big numbers
def RandomQuickSort(A , left ,right):
    if left >= right:
        return

    i = random.randint(left, right)
    j = random.randint(left, right)

    while (i == j):
        j = random.randint(left, right)

    if i > j:
        A[i], A[left] = A[left], A[i]
        A[j], A[right] = A[right], A[j]

    p = left
    q = right
    l = left + 1
    k = l
    g = right - 1
    if A[p] > A[q]:
        A[left], A[right] = A[right], A[left]
    while k <= g:
        if A[k] < A[p]:  # if the element in k is smaller than the element of the left pivot
            A[k], A[l] = A[l], A[k]  # Elements smaller than left pivot in the left
            l = l + 1
        else:
            if A[k] > A[q]:  # if element in k is bigger than the element in the right pivot
                while A[g] > A[q] and k < g:  # while the element in g is bigger than the right pivot
                    g = g - 1
                A[k], A[g] = A[g], A[k]  # Make elements bigger than right pivot in the right
                g = g - 1  # end place the element in between

                if A[k] < A[p]:
                    A[k], A[l] = A[l], A[k]
                    l = l + 1
        k = k + 1

    l = l - 1
    g = g + 1
    A[l], A[left] = A[left], A[l]  # place the left pivot in the right place
    A[g], A[right] = A[right], A[g]  # Place the right pivot in the right place
    DualQuickSort(A, left, l - 1)
    DualQuickSort(A, l + 1, g - 1)
    DualQuickSort(A, g + 1, right)


#GENERATE RANDOM ARRAY
def RandomArray(minElem , maxElem , size):

    randomArray = [random.randint(minElem , maxElem) for i in range (size)]
    return randomArray


#MAIN
randomArray = RandomArray(0, 1000, 10)  # random array generator
print(randomArray)
print(" ")
randomArray[len(randomArray) - 1], randomArray[1] = randomArray[1], randomArray[len(randomArray) - 1] # Switching the second adn last element
DualQuickSort(randomArray , 0 , 9)  # Taking the first and second elements as pivots
print("SORTED ARRAYS USING DUAL PIVOT QUICK SORT:")
print(randomArray)
print("\n")

randomArray = RandomArray(0, 1000, 10)  # random array generator
print(randomArray)
print(" ")
DualQuickSort(randomArray , 0 , 9)
print("SORTED ARRAYS USING RANDOMIZED PIVOT QUICK SORT:")
print(randomArray)


#references: https://kluedo.ub.uni-kl.de/frontdoor/deliver/index/docId/4468/file/wild-dissertation.pdf