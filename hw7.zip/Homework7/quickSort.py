import random
import time
import csv

#Lomoto partition Makes the elements bigger than pivot in the right side and the elements smaller in the left side
from typing import List


def LPartition(A , start , end):
    pivot = A[end]
    compareIndex = start

    for i in range(start , end  , 1):
        if(A[i] <= pivot):      #if the element in A[i] is less than our pivot
            A[i] , A[compareIndex] = A[compareIndex] , A[i]     #we make the compared element in the right of the pivot
                                                                # and A[i] the smaller element in the left of the pivot
            compareIndex = compareIndex + 1     # we increase the comparaison index by 1
    #we make the pivot element in its place where all elements in its left are smaller and all the elements in its right are bigger
    A[compareIndex] , A[end] = A[end] , A[compareIndex]
    return compareIndex

def LQuick_sort(A , start , end):
    if (start < end):
        pIndex = LPartition(A , start , end)     #apply partition sort to the array
        LQuick_sort(A , start , pIndex - 1 )      #Apply partition in the left side of the pivot
        LQuick_sort(A , pIndex + 1 , end) #Apply partition in the right side of the pivot

#----------------------------------------------------------------------------------
#Hoare partition uses 2 pointers if the elements in i are bigger than the pivot
#We find a smaller element in the right of the array using j and we swap them
def HPartition(A , start ,end):
    pivot = A[ (start + end) // 2 ]
    i = start
    j = end

    while 1:
        while A[i] < pivot:
            i = i + 1
        while A[j] > pivot:
            j = j - 1
        if i >= j:
            #A[i] , A[j] = A[j] , A[i]
            return i
        if A[j] <= pivot and A[i] >= pivot:
            A[j] , A[i] = A[i] , A[j]
            j = j - 1
            i = i + 1

def HQuick_sort(A , start , end):
    if (start < end):
        pIndex = HPartition(A , start , end)     #apply partition sort to the array
        HQuick_sort(A , start , pIndex - 1)      #Apply partition in the left side of the pivot
        HQuick_sort(A , pIndex + 1 , end) #Apply partition in the right side of the pivot

#-----------------------------------------------------------------------------------------------
#Median partition: We order the  three elements first last and median and we proceed to the partition
def MedianPartition(A , start ,end):
    median = (start + end) // 2

    if A[start] > A[median]:
        A[start] , A[median] = A[median] , A[start]

    if A[median] > A[end]:
        A[end], A[median] = A[median], A[end]

    if A[start] > A[end]:
        A[end], A[start] = A[start], A[end]

    #A[median] , A[end - 1] = A[end - 1] , A[median]
    pivot = A[median] #Since end is already sorted
    j = end - 1
    i = start + 1

    while 1:
        while A[i] < pivot:
            i = i + 1
        while A[j] > pivot:
            j = j - 1
        if i >= j:
            # A[i] , A[j] = A[j] , A[i]
            return i
        if A[j] <= pivot and A[i] >= pivot:
            A[j], A[i] = A[i], A[j]
            j = j - 1
            i = i + 1


def MQuick_sort(A, start, end):
    if (start < end):
        pIndex = HPartition(A, start, end)  # apply partition sort to the array
        MQuick_sort(A, start, pIndex - 1)  # Apply partition in the left side of the pivot
        MQuick_sort(A, pIndex + 1, end)  # Apply partition in the right side of the pivot

#-------------------------------------------------
def RandomArray(minElem , maxElem , size):

    randomArray = [random.randint(minElem , maxElem) for i in range (size)]
    return randomArray
#------------------------------------------------

#Main
randomArray = []
lomotoAvr = 0
hoareAvr = 0
medianAvr = 0

#Store the average running times in a file
with open("duration.csv" , 'w' , newline="") as duration_file:
    fieldnames = ['lomotoDuration' , 'hoareDuration' , 'medianDuration']
    csv_writer = csv.DictWriter(duration_file ,fieldnames = fieldnames)
    csv_writer.writeheader()



    for i in range(0 , 100000 , 1):
        randomArray = RandomArray(0 , 1000 , 1000)
        print("")#random array generator
        print(randomArray)
        print(" ")
        print("SORTED ARRAYS USING DIFFERENT METHODS:")
        lRandomArray = randomArray
        lomotoStart = time.time()
        LQuick_sort(lRandomArray , 0 , 999)
        lomotoStop = time.time()
        lomotoDuration = (lomotoStop - lomotoStart) * 1000000
        lomotoAvr += lomotoDuration
        print(lRandomArray)
        print(lomotoDuration)
       # csv_writer.writerow(lomotoDuration)

        hRandomArray = randomArray
        hoareStart = time.time()
        HQuick_sort(hRandomArray, 0, 999)
        hoareStop = time.time()
        hoareDuration = (hoareStop - hoareStart) * 1000000
        hoareAvr += hoareDuration
        print(hRandomArray)
        print(hoareDuration)
        #csv_writer.writerow(hoareDuration)



        mRandomArray = randomArray
        medianStart = time.time()
        MQuick_sort(mRandomArray, 0, 999)
        medianStop = time.time()
        medianDuration = (medianStop - medianStart) * 1000000
        medianAvr += medianDuration
        print(mRandomArray)
        print(medianDuration)


       # duration = (lomotoDuration , hoareDuration , medianDuration)
       # duration = ("MQS" , 3 , 5)
        #csv_writer.writerow({"lomotoDuration" : lomotoDuration ,"hoareDuration" : hoareDuration , "medianDuration" : medianDuration})
    medianAvr = medianAvr / 100000
    hoareAvr = hoareAvr / 100000
    lomotoAvr = lomotoAvr/ 100000
    print("medianAvr = " , medianAvr)
    print("hoareAvr = " , hoareAvr)
    print("lomotoAvr = " , lomotoAvr)


    #csv_writer("----------------------------------AVERAGE TIME---------------------------------------------------")
    csv_writer.writerow({"lomotoDuration" : lomotoAvr , "hoareDuration" : hoareAvr , "medianDuration" : medianAvr})




print("\n")





#refrences : https://kluedo.ub.uni-kl.de/frontdoor/deliver/index/docId/4468/file/wild-dissertation.pdf











